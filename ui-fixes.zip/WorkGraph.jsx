import { useEffect, useRef } from 'react';
import { Network } from 'vis-network';
import { DataSet } from 'vis-data';
import { decodeFilename } from '../api/utils';

const CYCLE_COLORS = {
  '상시': { background: '#3b82f6', border: '#2563eb' },
  '순기': { background: '#f59e0b', border: '#d97706' },
};

const EDGE_COLORS = {
  related: { color: '#94a3b8', dashes: false },
  shared_person: { color: '#8b5cf6', dashes: [6, 4] },
};

export default function WorkGraph({ categories, relations }) {
  const containerRef = useRef(null);
  const networkRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current || !categories?.length) return;

    const nodes = new DataSet(
      categories.map((cat, idx) => {
        const colors = CYCLE_COLORS[cat.cycle_type] || CYCLE_COLORS['상시'];
        const name = decodeFilename(cat.name);
        return {
          id: cat.id,
          label: `${name}\n(${cat.file_count}개 파일)`,
          value: cat.file_count * 15 + 30,
          color: {
            background: colors.background,
            border: colors.border,
            highlight: { background: colors.border, border: '#0f172a' },
          },
          // 핵심: 글자색 진한 다크그레이 + 노드 바깥에 표시
          font: {
            color: '#1e293b',
            size: 15,
            face: 'Pretendard, -apple-system, sans-serif',
            strokeWidth: 3,
            strokeColor: '#ffffff',
          },
          shape: 'dot',
          title: `${name}\n${cat.description || ''}\n주기: ${cat.cycle_type}${cat.cycle_detail ? ' (' + cat.cycle_detail + ')' : ''}`,
        };
      })
    );

    const edges = new DataSet(
      (relations || []).map((rel, i) => ({
        id: `edge_${i}`,
        from: rel.source,
        to: rel.target,
        color: { color: EDGE_COLORS[rel.type]?.color || '#94a3b8' },
        dashes: EDGE_COLORS[rel.type]?.dashes || false,
        title: rel.reason,
        width: 2,
        smooth: { type: 'curvedCW', roundness: 0.2 },
        arrows: { to: { enabled: false } },
      }))
    );

    const options = {
      nodes: {
        scaling: { min: 30, max: 70, label: { enabled: true, min: 13, max: 18 } },
        borderWidth: 3,
        shadow: { enabled: true, size: 8, x: 2, y: 3, color: 'rgba(0,0,0,0.12)' },
      },
      edges: {
        width: 2,
        smooth: { enabled: true, type: 'curvedCW', roundness: 0.2 },
      },
      layout: {
        improvedLayout: true,
      },
      physics: {
        enabled: true,
        barnesHut: {
          gravitationalConstant: -4000,
          centralGravity: 0.5,
          springLength: 180,
          springConstant: 0.06,
          damping: 0.3,
        },
        stabilization: { iterations: 200, fit: true },
      },
      interaction: {
        hover: true,
        tooltipDelay: 150,
        zoomView: true,
        dragView: true,
      },
    };

    networkRef.current = new Network(containerRef.current, { nodes, edges }, options);
    networkRef.current.once('stabilizationIterationsDone', () => {
      networkRef.current.fit({ animation: { duration: 500, easingFunction: 'easeInOutQuad' } });
    });

    return () => networkRef.current?.destroy();
  }, [categories, relations]);

  if (!categories?.length) return null;

  return (
    <div>
      <h3 style={{ fontSize: 17, fontWeight: 600, marginBottom: 12, color: '#1f2937' }}>
        업무 관계도
      </h3>
      <div style={{ display: 'flex', gap: 16, marginBottom: 12, fontSize: 13, color: '#6b7280', flexWrap: 'wrap' }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#3b82f6', display: 'inline-block' }} />
          상시 업무
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#f59e0b', display: 'inline-block' }} />
          순기 업무
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 20, height: 2, background: '#94a3b8', display: 'inline-block' }} />
          연관 업무
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          <span style={{ width: 20, height: 0, borderTop: '2px dashed #8b5cf6', display: 'inline-block' }} />
          공통 관련자
        </span>
      </div>
      <div ref={containerRef} style={{
        width: '100%', height: 420, border: '1px solid #e5e7eb',
        borderRadius: 12, background: '#f8fafc',
      }} />
      <p style={{ fontSize: 12, color: '#9ca3af', marginTop: 8, textAlign: 'center' }}>
        노드를 드래그하거나 스크롤로 확대/축소 · 노드 크기 = 파일 수
      </p>
    </div>
  );
}
