import { useState } from 'react';
import { decodeFilename } from '../api/utils';

const PRIORITY_STYLE = {
  high: { bg: '#fef2f2', border: '#fca5a5', label: '필수', color: '#991b1b' },
  medium: { bg: '#fefce8', border: '#fde68a', label: '중요', color: '#854d0e' },
  low: { bg: '#f0fdf4', border: '#86efac', label: '참고', color: '#166534' },
};

const RISK_COLORS = {
  High:   { bg: '#ef4444', text: 'white', cardBorder: '#fca5a5', cardBg: '#fef2f2' },
  Medium: { bg: '#f59e0b', text: 'white', cardBorder: '#fde68a', cardBg: '#fefce8' },
  Low:    { bg: '#10b981', text: 'white', cardBorder: '#86efac', cardBg: '#f0fdf4' },
};

function ProgressBar({ score, color }) {
  return (
    <div style={{ width: '100%', height: 6, background: '#e5e7eb', borderRadius: 3, overflow: 'hidden' }}>
      <div style={{
        width: `${Math.min(100, Math.max(0, score))}%`, height: '100%',
        background: color, borderRadius: 3, transition: 'width 0.5s ease',
      }} />
    </div>
  );
}

export default function Interview({ data, onSubmitAnswers, loading }) {
  const [answers, setAnswers] = useState({});
  if (!data) return null;

  const { reports, total_questions } = data;
  const answeredCount = Object.values(answers).filter((v) => v.trim()).length;

  const handleAnswer = (qid, value) => setAnswers((prev) => ({ ...prev, [qid]: value }));
  const handleSubmit = () => onSubmitAnswers(answers);

  return (
    <div>
      {/* ─── 상단 카드: 프로그레스 바 + 위험도 ─── */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
        gap: 12, marginBottom: 24,
      }}>
        {reports.map((r) => {
          const risk = RISK_COLORS[r.risk_level] || RISK_COLORS.Medium;
          const barColor = r.score >= 70 ? '#10b981' : r.score >= 40 ? '#f59e0b' : '#ef4444';
          return (
            <div key={r.category_id} style={{
              padding: 16, background: 'white', borderRadius: 12,
              border: `1px solid ${risk.cardBorder}`,
              boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 15, fontWeight: 600, color: '#1f2937' }}>
                  {decodeFilename(r.category_name)}
                </span>
                <span style={{
                  padding: '2px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600,
                  background: risk.bg, color: risk.text,
                }}>
                  {r.risk_level}
                </span>
              </div>
              {/* 프로그레스 바 */}
              <ProgressBar score={r.score} color={barColor} />
              <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4, textAlign: 'right' }}>
                커버리지 {r.score}점
              </div>
            </div>
          );
        })}
      </div>

      {/* 안내 */}
      <div style={{
        padding: 14, background: '#eff6ff', borderRadius: 10,
        border: '1px solid #bfdbfe', marginBottom: 20, fontSize: 14, color: '#1e40af',
        lineHeight: 1.6,
      }}>
        💡 아래는 문서에서 확인되지 않은 사항입니다. 전임자가 답변하면 인수인계서에 반영됩니다.
        <br />답변하지 않아도 인수인계서 생성은 가능합니다.
      </div>

      {/* ─── 업무별 상세 ─── */}
      {reports.map((report) => {
        const risk = RISK_COLORS[report.risk_level] || RISK_COLORS.Medium;
        return (
          <div key={report.category_id} style={{
            marginBottom: 20, padding: 20, background: 'white',
            borderRadius: 12, border: `1px solid ${risk.cardBorder}`,
            boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
              <h3 style={{ margin: 0, fontSize: 16, fontWeight: 600, flex: 1, color: '#1f2937' }}>
                {decodeFilename(report.category_name)}
              </h3>
              <span style={{
                padding: '3px 10px', borderRadius: 12, fontSize: 11, fontWeight: 600,
                background: risk.bg, color: risk.text,
              }}>
                위험도 {report.risk_level}
              </span>
            </div>

            {/* 리스크 사유 */}
            {report.risk_reason && (
              <div style={{
                fontSize: 13, padding: '8px 12px', borderRadius: 8, marginBottom: 12,
                background: risk.cardBg, color: '#374151', lineHeight: 1.5,
                borderLeft: `3px solid ${risk.bg}`,
              }}>
                {report.risk_reason}
              </div>
            )}

            {/* D-day 체크리스트 */}
            {report.dday_checklist && Object.keys(report.dday_checklist).length > 0 && (
              <div style={{
                marginBottom: 14, padding: 14, background: '#f8fafc', borderRadius: 10,
                border: '1px solid #e2e8f0',
              }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#1e293b', marginBottom: 10 }}>
                  📋 인수인계 D-day 체크리스트
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {Object.entries(report.dday_checklist).map(([day, items]) => (
                    <div key={day} style={{
                      flex: '1 1 140px', padding: 10, background: 'white', borderRadius: 8,
                      border: '1px solid #e5e7eb', minWidth: 140,
                    }}>
                      <div style={{
                        fontSize: 12, fontWeight: 700, color: '#2563eb',
                        padding: '2px 8px', background: '#dbeafe', borderRadius: 4,
                        display: 'inline-block', marginBottom: 6,
                      }}>{day}</div>
                      {(items || []).map((item, i) => (
                        <div key={i} style={{ fontSize: 12, color: '#475569', padding: '2px 0', lineHeight: 1.4 }}>
                          ☐ {item}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ─── 2열 분할: 확인된 항목 / 결손 항목 ─── */}
            {(report.found?.length > 0 || report.missing?.length > 0) && (
              <div style={{
                display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10,
                marginBottom: 14,
              }}>
                {/* 확인된 항목 */}
                <div style={{
                  padding: 12, background: '#f0fdf4', borderRadius: 10,
                  border: '1px solid #bbf7d0',
                }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#166534', marginBottom: 8 }}>
                    ✅ 문서에서 확인됨
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                    {(report.found || []).map((item, i) => (
                      <span key={i} style={{
                        fontSize: 12, color: '#166534', padding: '3px 8px',
                        background: '#dcfce7', borderRadius: 6, lineHeight: 1.4,
                      }}>
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 결손 항목 */}
                <div style={{
                  padding: 12, background: '#fef2f2', borderRadius: 10,
                  border: '1px solid #fecaca',
                }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#991b1b', marginBottom: 8 }}>
                    ❌ 추가 확인 필요
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                    {(report.missing || []).map((item, i) => (
                      <span key={i} style={{
                        fontSize: 12, color: '#991b1b', padding: '3px 8px',
                        background: '#fee2e2', borderRadius: 6, lineHeight: 1.4,
                      }}>
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* 질문 목록 */}
            {report.questions.map((q) => {
              const ps = PRIORITY_STYLE[q.priority] || PRIORITY_STYLE.medium;
              return (
                <div key={q.id} style={{
                  padding: 14, marginBottom: 10, borderRadius: 10,
                  background: ps.bg, border: `1px solid ${ps.border}`,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                    <span style={{
                      padding: '2px 8px', borderRadius: 12, fontSize: 11,
                      fontWeight: 600, color: ps.color, background: 'white',
                      border: `1px solid ${ps.border}`,
                    }}>
                      {ps.label}
                    </span>
                    <span style={{ fontSize: 14, fontWeight: 500, color: '#1f2937', lineHeight: 1.4 }}>
                      {q.question}
                    </span>
                  </div>
                  {q.why && (
                    <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8, paddingLeft: 4 }}>
                      💬 {q.why}
                    </div>
                  )}
                  <textarea
                    value={answers[q.id] || ''}
                    onChange={(e) => handleAnswer(q.id, e.target.value)}
                    placeholder="전임자 답변을 입력하세요..."
                    rows={2}
                    style={{
                      width: '100%', padding: '8px 10px', borderRadius: 8,
                      border: '1px solid #d1d5db', fontSize: 14, resize: 'vertical',
                      fontFamily: 'inherit', lineHeight: 1.5,
                    }}
                  />
                </div>
              );
            })}
          </div>
        );
      })}

      {/* 제출 버튼 */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '16px 0', borderTop: '1px solid #e5e7eb', marginTop: 8,
      }}>
        <span style={{ fontSize: 14, color: '#6b7280' }}>
          {answeredCount}/{total_questions}개 답변 완료
        </span>
        <button
          onClick={handleSubmit}
          disabled={loading}
          style={{
            padding: '12px 28px', background: loading ? '#9ca3af' : '#2563eb',
            color: 'white', border: 'none', borderRadius: 10,
            fontSize: 15, fontWeight: 600, cursor: loading ? 'not-allowed' : 'pointer',
            boxShadow: loading ? 'none' : '0 2px 8px rgba(37,99,235,0.3)',
          }}
        >
          {loading ? '처리 중...' : '✅ 답변 제출 후 인수인계서 생성'}
        </button>
      </div>
    </div>
  );
}
