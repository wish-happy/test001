/**
 * #Uxxxx 형태의 유니코드 이스케이프를 한글로 디코딩
 * 예: "#Ub514#Uc9c0#Ud138.txt" → "디지털.txt"
 */
export function decodeFilename(name) {
  if (!name) return name;
  return name.replace(/#U([0-9a-fA-F]{4})/g, (_, hex) =>
    String.fromCharCode(parseInt(hex, 16))
  );
}
