/**
 * #Uxxxx 형태의 유니코드 이스케이프를 한글로 디코딩
 */
export function decodeFilename(name) {
  if (!name) return name;
  return name.replace(/#U([0-9a-fA-F]{4})/g, (_, hex) =>
    String.fromCharCode(parseInt(hex, 16))
  );
}
