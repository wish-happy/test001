"""
QA Chatbot — 전임자 자료 기반 RAG 챗봇
후임자가 "이 업무 담당자 누구야?" 같은 질문을 하면
문서 근거와 함께 답변
"""

import json
from .file_parser import ParsedFile
from .classifier import WorkCategory
from .llm_adapter import LLMAdapter


class QAChatbot:
    """문서 기반 Q&A 챗봇 (간이 RAG)"""

    def __init__(self, llm: LLMAdapter):
        self.llm = llm
        self.context_docs: list[dict] = []
        self.categories: list[dict] = []
        self.chat_history: list[dict] = []

    def load_context(
        self,
        parsed_files: list[ParsedFile],
        categories: list[WorkCategory] = None,
        interview_answers: dict = None,
    ):
        """문서와 분류 결과를 컨텍스트로 로드"""
        self.context_docs = []
        for pf in parsed_files:
            self.context_docs.append({
                "filename": pf.filename,
                "folder": pf.metadata.get("parent_folder", "."),
                "content": pf.content[:2000],  # 토큰 제한 고려
            })

        if categories:
            self.categories = [cat.to_dict() for cat in categories]

        self.interview_data = interview_answers or {}
        self.chat_history = []

    def ask(self, question: str) -> dict:
        """질문에 대해 문서 근거 기반 답변"""
        # 관련 문서 검색 (키워드 기반 간이 검색)
        relevant_docs = self._search_relevant(question, top_k=5)

        system_prompt = """당신은 엄격한 기준을 가진 업무 인수인계 전문 AI 비서입니다.
전임자의 업무 문서를 기반으로 후임자의 질문에 답변합니다.

[절대 규칙]
1. 반드시 제공된 [참조 문서]에 적힌 사실만을 기반으로 답변하세요.
2. 문서에 기재되지 않은 내용은 절대로 상상하여 지어내지 마세요.
   → "해당 내용은 문서에 기재되어 있지 않습니다. 전임자에게 직접 확인이 필요합니다."
3. 답변에 반드시 [출처: 파일명 - 관련 부분]을 명시하세요.
4. 법령·규정이 언급된 경우 "⚠️ 최신 법령 여부는 별도 확인이 필요합니다"를 추가하세요.
5. 말투는 명확하고 신뢰성 있는 비즈니스 어조를 유지하세요.

응답 형식 (JSON):
{
  "answer": "답변 내용 (출처 포함)",
  "sources": ["근거파일1.hwp", "근거파일2.xlsx"],
  "confidence": "high/medium/low",
  "related_category": "관련 업무명 (있으면)"
}"""

        context_str = json.dumps(relevant_docs, ensure_ascii=False, indent=2)
        categories_str = json.dumps(self.categories[:5], ensure_ascii=False, indent=2) if self.categories else "없음"

        # 최근 대화 히스토리 (최대 5턴)
        history_str = ""
        if self.chat_history:
            recent = self.chat_history[-5:]
            history_str = "\n이전 대화:\n" + "\n".join(
                f"Q: {h['question']}\nA: {h['answer']}" for h in recent
            )

        user_prompt = f"""관련 문서:
{context_str}

업무 분류:
{categories_str}
{history_str}

질문: {question}"""

        try:
            result = self.llm.complete_json(system_prompt, user_prompt)
        except Exception:
            result = {
                "answer": "LLM 연결 오류입니다. API 설정을 확인해주세요.",
                "sources": [],
                "confidence": "low",
            }

        # 히스토리 저장
        self.chat_history.append({
            "question": question,
            "answer": result.get("answer", ""),
        })

        return result

    def _search_relevant(self, query: str, top_k: int = 5) -> list[dict]:
        """키워드 기반 간이 문서 검색"""
        # 간단한 TF 기반 관련도 점수
        query_tokens = set(query.lower().replace("?", "").replace(".", "").split())

        scored = []
        for doc in self.context_docs:
            content_lower = doc["content"].lower()
            score = sum(1 for token in query_tokens if token in content_lower)
            # 파일명 매칭 가산점
            filename_lower = doc["filename"].lower()
            score += sum(2 for token in query_tokens if token in filename_lower)
            scored.append((score, doc))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [doc for _, doc in scored[:top_k] if _ > 0] or scored[:top_k]
