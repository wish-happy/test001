"""
LLM Adapter — 모델 비종속 구조
OpenAI 호환 API를 사용하는 모든 모델을 지원합니다.
설정 파일에서 모델을 교체하면 코드 수정 없이 전환됩니다.
"""

from openai import OpenAI
from pydantic import BaseModel
from typing import Optional
import json
import os


class LLMConfig(BaseModel):
    """LLM 연결 설정"""
    provider: str = "openai"          # openai, ollama, vllm, exaone 등
    model: str = "gpt-4o-mini"        # 모델명
    base_url: Optional[str] = None    # 커스텀 엔드포인트 (Ollama 등)
    api_key: Optional[str] = None     # API 키
    temperature: float = 0.3
    max_tokens: int = 4096


# 프리셋: 공통기반 지원 모델 포함
MODEL_PRESETS = {
    "openai": LLMConfig(
        provider="openai",
        model="gpt-4o-mini",
        api_key=os.getenv("OPENAI_API_KEY", ""),
    ),
    "ollama-gemma": LLMConfig(
        provider="ollama",
        model="gemma2:9b",
        base_url="http://localhost:11434/v1",
        api_key="ollama",
    ),
    "ollama-llama": LLMConfig(
        provider="ollama",
        model="llama3.1:8b",
        base_url="http://localhost:11434/v1",
        api_key="ollama",
    ),
    "exaone": LLMConfig(
        provider="exaone",
        model="LGAI-EXAONE/EXAONE-3.5-7.8B-Instruct",
        base_url=os.getenv("EXAONE_BASE_URL", ""),
        api_key=os.getenv("EXAONE_API_KEY", ""),
    ),
}


class LLMAdapter:
    """
    모델 교체 가능한 LLM 어댑터.
    OpenAI 호환 API를 사용하므로 base_url만 바꾸면
    Ollama, vLLM, HyperCLOVA X, EXAONE 등 어떤 모델이든 연결 가능.
    """

    def __init__(self, config: Optional[LLMConfig] = None, preset: Optional[str] = None):
        if preset and preset in MODEL_PRESETS:
            self.config = MODEL_PRESETS[preset]
        elif config:
            self.config = config
        else:
            self.config = MODEL_PRESETS["openai"]

        self.client = OpenAI(
            api_key=self.config.api_key or "dummy",
            base_url=self.config.base_url,
        )

    def complete(self, system_prompt: str, user_prompt: str) -> str:
        """단일 프롬프트 완성"""
        response = self.client.chat.completions.create(
            model=self.config.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        )
        return response.choices[0].message.content

    def complete_json(self, system_prompt: str, user_prompt: str) -> dict:
        """JSON 응답을 파싱하여 반환"""
        raw = self.complete(system_prompt, user_prompt)
        # ```json ... ``` 감싸진 경우 처리
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[1] if "\n" in cleaned else cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        return json.loads(cleaned)

    def get_model_info(self) -> dict:
        """현재 연결된 모델 정보 반환"""
        return {
            "provider": self.config.provider,
            "model": self.config.model,
            "base_url": self.config.base_url or "default",
        }
